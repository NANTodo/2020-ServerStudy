var food_name;
if(food_name=="곱창"){
    document.getElementById('picture').src=logo_info()
        function logo_info() {
        var img_src;
            img_src = './images/gopchang.jpg';
        return img_src;
        }
    food_name = "곱창";

    // 인스타그램 기능 추가
    document.getElementById('insta').src='//lightwidget.com/widgets/15dacccc63855f0c9a837cfa56cc1e05.html';

}else if(food_name=="닭발"){
    document.getElementById('picture').src=logo_info()
    function logo_info() {
    var img_src;
        img_src = './images/dakbal.jpg';
    return img_src;
    }
    food_name = "닭발";

    document.getElementById('insta').src='//lightwidget.com/widgets/fc211152eb9450a49ddddbc1be37b435.html';

}else if(food_name=="파스타"){
    document.getElementById('picture').src=logo_info()
    function logo_info() {
    var img_src;
        img_src = './images/donuts.jpg';
    return img_src;
    }
    food_name = "파스타";

    document.getElementById('insta').src='//lightwidget.com/widgets/fc211152eb9450a49ddddbc1be37b435.html';
}else if(food_name=="떡볶이"){
    document.getElementById('picture').src=logo_info()
    function logo_info() {
    var img_src;
        img_src = './images/donuts.jpg';
    return img_src;
    }
    food_name = "떡볶이";

    document.getElementById('insta').src='//lightwidget.com/widgets/fc211152eb9450a49ddddbc1be37b435.html';
}else if(food_name=="초밥"){
    document.getElementById('picture').src=logo_info()
    function logo_info() {
    var img_src;
        img_src = './images/donuts.jpg';
    return img_src;
    }
    food_name = "초밥";

    document.getElementById('insta').src='//lightwidget.com/widgets/fc211152eb9450a49ddddbc1be37b435.html';
}else if(food_name=="마라탕"){
    document.getElementById('picture').src=logo_info()
    function logo_info() {
    var img_src;
        img_src = './images/maratang.jpg';
    return img_src;
    }
    food_name = "마라탕";

    document.getElementById('insta').src='//lightwidget.com/widgets/fc211152eb9450a49ddddbc1be37b435.html';
}else if(food_name=="파전"){
    document.getElementById('picture').src=logo_info()
    function logo_info() {
    var img_src;
        img_src = './images/pajeon.jpg';
    return img_src;
    }
    food_name = "파전";

    document.getElementById('insta').src='//lightwidget.com/widgets/fc211152eb9450a49ddddbc1be37b435.html';
}else if(food_name=="전골"){
    document.getElementById('picture').src=logo_info()
    function logo_info() {
    var img_src;
        img_src = './images/jeongol.jpg';
    return img_src;
    }
    food_name = "전골";

    document.getElementById('insta').src='//lightwidget.com/widgets/fc211152eb9450a49ddddbc1be37b435.html';
}else if(food_name=="치킨"){
    document.getElementById('picture').src=logo_info()
    function logo_info() {
    var img_src;
        img_src = './images/chicken.jpg';
    return img_src;
    }
    food_name = "치킨";

    document.getElementById('insta').src='//lightwidget.com/widgets/fc211152eb9450a49ddddbc1be37b435.html';
}else if(food_name=="커리"){
    document.getElementById('picture').src=logo_info()
    function logo_info() {
    var img_src;
        img_src = './images/curry.jpg';
    return img_src;
    }
    food_name = "커리";

    document.getElementById('insta').src='//lightwidget.com/widgets/fc211152eb9450a49ddddbc1be37b435.html';
}else if(food_name=="브런치"){
    document.getElementById('picture').src=logo_info()
    function logo_info() {
    var img_src;
        img_src = './images/brunch.jpg';
    return img_src;
    }
    food_name = "브런치";

    document.getElementById('insta').src='//lightwidget.com/widgets/fc211152eb9450a49ddddbc1be37b435.html';
}else if(food_name=="라면"){
    document.getElementById('picture').src=logo_info()
    function logo_info() {
    var img_src;
        img_src = './images/ramyeon.jpg';
    return img_src;
    }
    food_name = "라면";

    document.getElementById('insta').src='//lightwidget.com/widgets/fc211152eb9450a49ddddbc1be37b435.html';
}else if(food_name=="샐러드"){
    document.getElementById('picture').src=logo_info()
    function logo_info() {
    var img_src;
        img_src = './images/salad.jpg';
    return img_src;
    }
    food_name = "샐러드";

    document.getElementById('insta').src='//lightwidget.com/widgets/fc211152eb9450a49ddddbc1be37b435.html';
}else if(food_name=="도넛"){
    document.getElementById('picture').src=logo_info()
    function logo_info() {
    var img_src;
        img_src = './images/donuts.jpg';
    return img_src;
    }
    food_name = "도넛";

    document.getElementById('insta').src='//lightwidget.com/widgets/fc211152eb9450a49ddddbc1be37b435.html';
}else if(food_name=="쌀국수"){
    document.getElementById('picture').src=logo_info()
    function logo_info() {
    var img_src;
        img_src = './images/ricenoodles.jpg';
    return img_src;
    }
    food_name = "쌀국수";

    document.getElementById('insta').src='//lightwidget.com/widgets/fc211152eb9450a49ddddbc1be37b435.html';
}else{
    food_name="세종대";
}
